import boto3
import json
import os
from datetime import datetime
 
s3_client = boto3.client("s3")
sns = boto3.client("sns")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(os.environ["AUDIT_TABLE"])
SNS_TOPIC = os.environ["SNS_TOPIC_ARN"]
 
 
def lambda_handler(event, context):
    detail = event.get("detail", {})
    finding_type = detail.get("type", "Unknown")
    finding_id = detail.get("id", "unknown")
    severity = detail.get("severity", 0)
    account_id = detail.get("accountId", "unknown")
    region = detail.get("region", "unknown")
 
    # Extract the bucket name from the finding
    resource = detail.get("resource", {})
    s3_bucket = resource.get("s3BucketDetails", [{}])
    bucket_name = None
    if s3_bucket and len(s3_bucket) > 0:
        bucket_name = s3_bucket[0].get("name", None)
 
    if not bucket_name:
        print(f"No bucket name found in finding {finding_id}")
        return {"statusCode": 400, "body": "No bucket name in finding"}
 
    print(f"REMEDIATION START: {finding_type} on {bucket_name}")
 
    actions_taken = []
 
    # Step 1: Re-enable public access block
    try:
        s3_client.put_public_access_block(
            Bucket=bucket_name,
            PublicAccessBlockConfiguration={
                "BlockPublicAcls": True,
                "IgnorePublicAcls": True,
                "BlockPublicPolicy": True,
                "RestrictPublicBuckets": True
            }
        )
        actions_taken.append(f"Public access block re-enabled on {bucket_name}")
    except Exception as e:
        print(f"Could not set public access block: {e}")
        actions_taken.append(f"FAILED to set public access block: {str(e)}")
 
    # Step 2: Send SNS alert
    message = (f"GUARDDUTY S3 REMEDIATION\n\n"
               f"Finding: {finding_type}\n"
               f"Severity: {severity}\n"
               f"Bucket: {bucket_name}\n"
               f"Account: {account_id}\n"
               f"Region: {region}\n\n"
               f"Actions Taken:\n" +
               "\n".join(f"  - {a}" for a in actions_taken) +
               f"\n\nReview CloudTrail for who made the bucket public.")
 
    try:
        sns.publish(
            TopicArn=SNS_TOPIC,
            Subject=f"GuardDuty S3 Remediation: {bucket_name}",
            Message=message
        )
    except Exception as e:
        print(f"Could not send SNS: {e}")
 
    # Step 3: Log to DynamoDB
    try:
        table.put_item(Item={
            "finding_id": finding_id,
            "timestamp": datetime.utcnow().isoformat(),
            "finding_type": finding_type,
            "severity": str(severity),
            "resource_type": "S3",
            "resource_id": bucket_name,
            "actions_taken": json.dumps(actions_taken),
            "account_id": account_id,
            "region": region
        })
    except Exception as e:
        print(f"Could not write audit record: {e}")
 
    print(f"REMEDIATION COMPLETE: {len(actions_taken)} actions taken")
    return {"statusCode": 200, "body": json.dumps(actions_taken)}
